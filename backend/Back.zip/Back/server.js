const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// Test route
app.get("/", (req, res) => {
  res.send("Server is running 🚀");
});

// Example API
app.get("/api/listings", (req, res) => {
  res.json([
    { dish: "Kadi Chawal", price: 40 },
    { dish: "Paneer", price: 60 }
  ]);
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});